import styled from "styled-components";

export const Container = styled.section`
  height: 100vh;
  padding: 30px;
  flex: 1;

  display: flex;
  align-items: center;
  justify-content: center;
`;
